import { useCallback, useEffect, useState } from 'react';
import { api, heure, messageErreur } from '../api.js';
import Message from '../components/Message.jsx';

export const LIBELLES = { confirmee: 'Confirmée', en_attente: "En file d'attente", annulee: 'Annulée' };

export default function ReservationsAdmin() {
  const [lignes, setLignes] = useState([]);
  const [message, setMessage] = useState(null);

  const charger = useCallback(async () => setLignes(await api.get('/reservations')), []);

  useEffect(() => {
    charger().catch((e) => setMessage({ type: 'err', text: messageErreur(e) }));
  }, [charger]);

  const annuler = async (r) => {
    if (!window.confirm('Annuler cette réservation ?')) return;
    try {
      const res = await api.post(`/reservations/${r.num_reservation}/annuler`);
      setMessage({
        type: 'ok',
        text: res.promue
          ? `Réservation annulée. ${res.promue.etudiant.nom} ${res.promue.etudiant.prenoms} passe de la file d'attente à « confirmée ».`
          : 'Réservation annulée.',
      });
      await charger();
    } catch (e) {
      setMessage({ type: 'err', text: messageErreur(e) });
    }
  };

  return (
    <section className="carte">
      <h2>Réservations</h2>
      <Message message={message} onClose={() => setMessage(null)} />
      <div className="tableau">
        <table>
          <thead>
            <tr>
              <th>N°</th>
              <th>Demandée le</th>
              <th>Étudiant</th>
              <th>Créneau</th>
              <th>Salle</th>
              <th>Jury</th>
              <th>Statut</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {lignes.length === 0 && (
              <tr>
                <td colSpan="8" className="vide">
                  Aucune réservation.
                </td>
              </tr>
            )}
            {lignes.map((r) => (
              <tr key={r.num_reservation}>
                <td>{r.num_reservation}</td>
                <td>{new Date(r.date_heure_demande).toLocaleString('fr-FR')}</td>
                <td>
                  {r.etudiant.nom} {r.etudiant.prenoms}
                  <br />
                  <small>{r.num_matricule}</small>
                </td>
                <td>
                  {r.creneau.date_creneau} {heure(r.creneau.heure_debut)}–{heure(r.creneau.heure_fin)}
                </td>
                <td>
                  {r.creneau.num_salle}
                  <br />
                  <small>{r.creneau.salle?.emplacement?.code_emplacement}</small>
                </td>
                <td>{r.jurys.map((j) => j.nom).join(', ')}</td>
                <td>
                  <span className={`badge ${r.statut}`}>{LIBELLES[r.statut]}</span>
                  {r.position && <small> (n°{r.position})</small>}
                </td>
                <td className="actions">
                  {r.statut !== 'annulee' && (
                    <button className="danger" onClick={() => annuler(r)}>
                      Annuler
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
