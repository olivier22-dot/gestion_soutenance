-- =====================================================================
--  Gestion de réservation de créneaux de soutenance et file d'attente
--  PostgreSQL — structure + données de démonstration
--  Utilisation :  psql -U postgres -d soutenance -f database/soutenance.sql
--  (alternative aux migrations Laravel : utiliser l'un OU l'autre)
-- =====================================================================

DROP TABLE IF EXISTS jury_reservation, reservations, creneaux, encadrements, jurys, etudiants, salles, emplacements CASCADE;

CREATE TABLE emplacements (
    code_emplacement VARCHAR(20) PRIMARY KEY,
    adresse          VARCHAR(255) NOT NULL,
    created_at       TIMESTAMP(0),
    updated_at       TIMESTAMP(0)
);

CREATE TABLE salles (
    num_salle        VARCHAR(20) PRIMARY KEY,
    capacite         SMALLINT NOT NULL CHECK (capacite > 0),
    code_emplacement VARCHAR(20) NOT NULL
                     REFERENCES emplacements(code_emplacement) ON UPDATE CASCADE ON DELETE RESTRICT,
    created_at       TIMESTAMP(0),
    updated_at       TIMESTAMP(0)
);

CREATE TABLE etudiants (
    num_matricule    VARCHAR(20) PRIMARY KEY,
    nom              VARCHAR(100) NOT NULL,
    prenoms          VARCHAR(150) NOT NULL,
    niveau           VARCHAR(20)  NOT NULL,
    parcours         VARCHAR(100) NOT NULL,
    telephone        VARCHAR(30),
    email            VARCHAR(150) NOT NULL UNIQUE,
    visa_soutenance  BOOLEAN NOT NULL DEFAULT FALSE,
    rapport_lecture  BOOLEAN NOT NULL DEFAULT FALSE,
    memoire          VARCHAR(255),
    created_at       TIMESTAMP(0),
    updated_at       TIMESTAMP(0)
);

CREATE TABLE jurys (
    num_jury   BIGSERIAL PRIMARY KEY,
    nom        VARCHAR(100) NOT NULL,
    prenoms    VARCHAR(150) NOT NULL,
    grade      VARCHAR(100) NOT NULL,
    role       VARCHAR(100) NOT NULL,
    created_at TIMESTAMP(0),
    updated_at TIMESTAMP(0)
);

-- Association ENCADREUR (étudiant 0,n — 0,n jury)
CREATE TABLE encadrements (
    num_matricule VARCHAR(20) NOT NULL REFERENCES etudiants(num_matricule) ON UPDATE CASCADE ON DELETE CASCADE,
    num_jury      BIGINT      NOT NULL REFERENCES jurys(num_jury) ON DELETE CASCADE,
    PRIMARY KEY (num_matricule, num_jury)
);

-- Créneau : durée variable, se déroule dans une salle (SE_DEROULER_SUR)
CREATE TABLE creneaux (
    num_creneau  BIGSERIAL PRIMARY KEY,
    date_creneau DATE NOT NULL,
    heure_debut  TIME(0) NOT NULL,
    heure_fin    TIME(0) NOT NULL,
    num_salle    VARCHAR(20) NOT NULL REFERENCES salles(num_salle) ON UPDATE CASCADE ON DELETE RESTRICT,
    created_at   TIMESTAMP(0),
    updated_at   TIMESTAMP(0),
    CONSTRAINT creneaux_heures_chk CHECK (heure_fin > heure_debut)
);
CREATE INDEX creneaux_salle_date_idx ON creneaux (num_salle, date_creneau);

CREATE TABLE reservations (
    num_reservation    BIGSERIAL PRIMARY KEY,
    date_heure_demande TIMESTAMP(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    statut             VARCHAR(20)  NOT NULL DEFAULT 'en_attente',
    num_matricule      VARCHAR(20)  NOT NULL REFERENCES etudiants(num_matricule) ON UPDATE CASCADE ON DELETE RESTRICT,
    num_creneau        BIGINT       NOT NULL REFERENCES creneaux(num_creneau) ON DELETE RESTRICT,
    created_at         TIMESTAMP(0),
    updated_at         TIMESTAMP(0),
    CONSTRAINT reservations_statut_chk CHECK (statut IN ('en_attente','confirmee','annulee'))
);
CREATE INDEX reservations_creneau_statut_idx ON reservations (num_creneau, statut, date_heure_demande);
-- Un créneau : une seule réservation confirmée
CREATE UNIQUE INDEX reservations_une_confirmee_par_creneau ON reservations (num_creneau) WHERE statut = 'confirmee';
-- Un étudiant : une seule réservation active (confirmée ou en attente)
CREATE UNIQUE INDEX reservations_une_active_par_etudiant ON reservations (num_matricule) WHERE statut IN ('en_attente','confirmee');

-- Les 3 membres du jury d'une réservation
CREATE TABLE jury_reservation (
    num_reservation BIGINT NOT NULL REFERENCES reservations(num_reservation) ON DELETE CASCADE,
    num_jury        BIGINT NOT NULL REFERENCES jurys(num_jury) ON DELETE RESTRICT,
    PRIMARY KEY (num_reservation, num_jury)
);

-- Règle "exactement 3 jurys par réservation" : vérifiée à la validation de la transaction
CREATE OR REPLACE FUNCTION verifier_trois_jurys() RETURNS trigger AS $$
DECLARE
    nb INTEGER;
    ref BIGINT;
BEGIN
    ref := COALESCE(NEW.num_reservation, OLD.num_reservation);
    IF EXISTS (SELECT 1 FROM reservations WHERE num_reservation = ref) THEN
        SELECT COUNT(*) INTO nb FROM jury_reservation WHERE num_reservation = ref;
        IF nb <> 3 THEN
            RAISE EXCEPTION 'La réservation % doit avoir exactement 3 membres de jury (actuellement %)', ref, nb;
        END IF;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE CONSTRAINT TRIGGER trg_trois_jurys
    AFTER INSERT OR DELETE ON jury_reservation
    DEFERRABLE INITIALLY DEFERRED
    FOR EACH ROW EXECUTE FUNCTION verifier_trois_jurys();

-- ---------------------------------------------------------------------
--  Données de démonstration
-- ---------------------------------------------------------------------
INSERT INTO emplacements (code_emplacement, adresse) VALUES
 ('BAT-A', 'Bâtiment A - Campus principal'),
 ('BAT-B', 'Bâtiment B - Annexe');

INSERT INTO salles (num_salle, capacite, code_emplacement) VALUES
 ('A101', 40, 'BAT-A'), ('A102', 25, 'BAT-A'), ('B201', 30, 'BAT-B');

INSERT INTO etudiants (num_matricule, nom, prenoms, niveau, parcours, email, visa_soutenance, rapport_lecture, memoire) VALUES
 ('2024001', 'RAKOTO', 'Jean',    'L2', 'Génie logiciel',   'jean.rakoto@example.com',  TRUE,  TRUE,  'Gestion de bibliothèque numérique'),
 ('2024002', 'RASOA',  'Marie',   'L2', 'Bases de données', 'marie.rasoa@example.com',  TRUE,  TRUE,  'Gestion des associations'),
 ('2024003', 'ANDRIA', 'Paul',    'L2', 'Génie logiciel',   'paul.andria@example.com',  TRUE,  TRUE,  'Application de pointage'),
 ('2024004', 'HERY',   'Lalaina', 'L2', 'Bases de données', 'lalaina.hery@example.com', FALSE, FALSE, NULL);

INSERT INTO jurys (nom, prenoms, grade, role) VALUES
 ('DUPONT',  'Alain', 'Professeur',            'Président'),
 ('MARTIN',  'Sophie','Maître de conférences', 'Examinateur'),
 ('RABE',    'Hery',  'Docteur',               'Encadreur'),
 ('RANDRIA', 'Noro',  'Docteur',               'Examinateur'),
 ('BERNARD', 'Luc',   'Professeur',            'Examinateur');

INSERT INTO encadrements (num_matricule, num_jury) VALUES ('2024001', 3), ('2024002', 3);

INSERT INTO creneaux (date_creneau, heure_debut, heure_fin, num_salle)
SELECT CURRENT_DATE + j, h.debut::time, h.fin::time, h.salle
FROM generate_series(1, 3) AS j,
     (VALUES ('08:00','09:00','A101'), ('09:30','10:30','A101'),
             ('11:00','12:30','A101'), ('14:00','15:00','B201')) AS h(debut, fin, salle);

-- Démo : 2024001 confirmé sur le créneau 1, 2024002 en file d'attente sur le même créneau
BEGIN;
INSERT INTO reservations (date_heure_demande, statut, num_matricule, num_creneau)
VALUES (CURRENT_TIMESTAMP, 'confirmee', '2024001', 1);
INSERT INTO jury_reservation (num_reservation, num_jury)
SELECT currval('reservations_num_reservation_seq'), x FROM unnest(ARRAY[1,2,3]) AS x;
COMMIT;

BEGIN;
INSERT INTO reservations (date_heure_demande, statut, num_matricule, num_creneau)
VALUES (CURRENT_TIMESTAMP, 'en_attente', '2024002', 1);
INSERT INTO jury_reservation (num_reservation, num_jury)
SELECT currval('reservations_num_reservation_seq'), x FROM unnest(ARRAY[1,4,5]) AS x;
COMMIT;
