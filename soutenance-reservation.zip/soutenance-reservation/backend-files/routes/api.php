<?php

use App\Http\Controllers\CreneauController;
use App\Http\Controllers\EmplacementController;
use App\Http\Controllers\EtudiantController;
use App\Http\Controllers\JuryController;
use App\Http\Controllers\PlanningController;
use App\Http\Controllers\ReservationController;
use App\Http\Controllers\SalleController;
use Illuminate\Support\Facades\Route;

Route::apiResource('emplacements', EmplacementController::class);
Route::apiResource('salles', SalleController::class);
Route::apiResource('jurys', JuryController::class);
Route::apiResource('etudiants', EtudiantController::class);
Route::put('etudiants/{id}/encadreurs', [EtudiantController::class, 'encadreurs']);
Route::apiResource('creneaux', CreneauController::class);

Route::get('planning', [PlanningController::class, 'index']);

Route::get('reservations', [ReservationController::class, 'index']);
Route::post('reservations', [ReservationController::class, 'store']);
Route::post('reservations/{id}/annuler', [ReservationController::class, 'annuler']);
