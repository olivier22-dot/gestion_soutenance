<?php

namespace Database\Seeders;

use App\Models\Creneau;
use App\Models\Emplacement;
use App\Models\Etudiant;
use App\Models\Jury;
use App\Models\Salle;
use App\Services\ReservationService;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        Emplacement::create(['code_emplacement' => 'BAT-A', 'adresse' => 'Bâtiment A - Campus principal']);
        Emplacement::create(['code_emplacement' => 'BAT-B', 'adresse' => 'Bâtiment B - Annexe']);

        foreach ([['A101', 40, 'BAT-A'], ['A102', 25, 'BAT-A'], ['B201', 30, 'BAT-B']] as [$num, $cap, $code]) {
            Salle::create(['num_salle' => $num, 'capacite' => $cap, 'code_emplacement' => $code]);
        }

        $etudiants = [
            ['2024001', 'RAKOTO', 'Jean', 'L2', 'Génie logiciel', 'jean.rakoto@example.com', true, true, 'Gestion de bibliothèque numérique'],
            ['2024002', 'RASOA', 'Marie', 'L2', 'Bases de données', 'marie.rasoa@example.com', true, true, 'Gestion des associations'],
            ['2024003', 'ANDRIA', 'Paul', 'L2', 'Génie logiciel', 'paul.andria@example.com', true, true, 'Application de pointage'],
            ['2024004', 'HERY', 'Lalaina', 'L2', 'Bases de données', 'lalaina.hery@example.com', false, false, null],
        ];
        foreach ($etudiants as [$mat, $nom, $prenoms, $niveau, $parcours, $email, $visa, $rapport, $memoire]) {
            Etudiant::create([
                'num_matricule' => $mat, 'nom' => $nom, 'prenoms' => $prenoms, 'niveau' => $niveau,
                'parcours' => $parcours, 'email' => $email, 'visa_soutenance' => $visa,
                'rapport_lecture' => $rapport, 'memoire' => $memoire,
            ]);
        }

        $jurys = [
            ['DUPONT', 'Alain', 'Professeur', 'Président'],
            ['MARTIN', 'Sophie', 'Maître de conférences', 'Examinateur'],
            ['RABE', 'Hery', 'Docteur', 'Encadreur'],
            ['RANDRIA', 'Noro', 'Docteur', 'Examinateur'],
            ['BERNARD', 'Luc', 'Professeur', 'Examinateur'],
        ];
        foreach ($jurys as [$nom, $prenoms, $grade, $role]) {
            Jury::create(compact('nom', 'prenoms', 'grade', 'role'));
        }

        Etudiant::find('2024001')->encadreurs()->sync([3]);
        Etudiant::find('2024002')->encadreurs()->sync([3]);

        // Créneaux de durées variables sur les 3 prochains jours
        $horaires = [['08:00', '09:00', 'A101'], ['09:30', '10:30', 'A101'], ['11:00', '12:30', 'A101'], ['14:00', '15:00', 'B201']];
        for ($jour = 1; $jour <= 3; $jour++) {
            foreach ($horaires as [$debut, $fin, $salle]) {
                Creneau::create([
                    'date_creneau' => now()->addDays($jour)->toDateString(),
                    'heure_debut' => $debut,
                    'heure_fin' => $fin,
                    'num_salle' => $salle,
                ]);
            }
        }

        // Démonstration : un étudiant confirmé, un autre en file d'attente sur le même créneau
        $service = app(ReservationService::class);
        $premier = Creneau::orderBy('num_creneau')->first();
        $service->demander('2024001', $premier->num_creneau, [1, 2, 3]);
        $service->demander('2024002', $premier->num_creneau, [1, 4, 5]);
    }
}
