<?php

namespace App\Services;

use App\Models\Creneau;
use App\Models\Etudiant;
use App\Models\Reservation;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Règles de gestion des réservations et de la file d'attente (premier arrivé, premier servi).
 */
class ReservationService
{
    /**
     * Un étudiant demande un créneau avec 3 membres de jury.
     * - créneau libre  => réservation confirmée
     * - créneau pris   => réservation placée en file d'attente (ordre d'arrivée)
     */
    public function demander(string $matricule, int $numCreneau, array $jurys): Reservation
    {
        return DB::transaction(function () use ($matricule, $numCreneau, $jurys) {
            // Verrou sur le créneau : deux demandes simultanées sont traitées l'une après l'autre
            $creneau = Creneau::whereKey($numCreneau)->lockForUpdate()->firstOrFail();
            $etudiant = Etudiant::findOrFail($matricule);
            $jurys = array_values(array_unique(array_map('intval', $jurys)));

            if (count($jurys) !== 3) {
                $this->refuser('jurys', 'Une soutenance nécessite exactement 3 membres de jury distincts.');
            }
            if (!$etudiant->visa_soutenance || !$etudiant->rapport_lecture) {
                $this->refuser('num_matricule', "L'étudiant doit avoir le visa de soutenance et le rapport de lecture.");
            }
            if ($this->debut($creneau)->isPast()) {
                $this->refuser('num_creneau', 'Ce créneau est déjà passé.');
            }

            $dejaActive = Reservation::where('num_matricule', $matricule)
                ->whereIn('statut', [Reservation::EN_ATTENTE, Reservation::CONFIRMEE])
                ->exists();
            if ($dejaActive) {
                $this->refuser('num_matricule', 'Cet étudiant a déjà une réservation active. Annulez-la avant d\'en faire une autre.');
            }

            $libre = !Reservation::where('num_creneau', $creneau->num_creneau)
                ->where('statut', Reservation::CONFIRMEE)
                ->exists();

            if ($libre && $this->juryOccupe($creneau, $jurys)) {
                $this->refuser('jurys', 'Un des membres du jury est déjà pris sur un créneau qui chevauche celui-ci.');
            }

            $reservation = Reservation::create([
                'date_heure_demande' => now(),
                'statut' => $libre ? Reservation::CONFIRMEE : Reservation::EN_ATTENTE,
                'num_matricule' => $matricule,
                'num_creneau' => $creneau->num_creneau,
            ]);
            $reservation->jurys()->attach($jurys);

            return $reservation;
        });
    }

    /**
     * Annule une réservation. Si elle était confirmée, la première demande
     * de la file d'attente dont le jury est disponible est confirmée à sa place.
     *
     * @return array{0: Reservation, 1: ?Reservation} [réservation annulée, réservation promue]
     */
    public function annuler(int $numReservation): array
    {
        return DB::transaction(function () use ($numReservation) {
            $reservation = Reservation::findOrFail($numReservation);
            $creneau = Creneau::whereKey($reservation->num_creneau)->lockForUpdate()->firstOrFail();
            $reservation->refresh();

            if ($reservation->statut === Reservation::ANNULEE) {
                $this->refuser('statut', 'Cette réservation est déjà annulée.');
            }

            $etaitConfirmee = $reservation->statut === Reservation::CONFIRMEE;
            $reservation->update(['statut' => Reservation::ANNULEE]);

            $promue = $etaitConfirmee ? $this->promouvoir($creneau) : null;

            return [$reservation, $promue];
        });
    }

    /** Confirme la première demande en attente (ordre d'arrivée) dont le jury est libre. */
    public function promouvoir(Creneau $creneau): ?Reservation
    {
        $attente = Reservation::with('jurys')
            ->where('num_creneau', $creneau->num_creneau)
            ->where('statut', Reservation::EN_ATTENTE)
            ->orderBy('date_heure_demande')
            ->orderBy('num_reservation')
            ->get();

        foreach ($attente as $candidate) {
            $ids = $candidate->jurys->pluck('num_jury')->all();
            if (!$this->juryOccupe($creneau, $ids)) {
                $candidate->update(['statut' => Reservation::CONFIRMEE]);
                return $candidate;
            }
        }

        return null;
    }

    /** Position dans la file d'attente (1 = prochain), null si la réservation n'est pas en attente. */
    public function position(Reservation $reservation): ?int
    {
        if ($reservation->statut !== Reservation::EN_ATTENTE) {
            return null;
        }

        $avant = Reservation::where('num_creneau', $reservation->num_creneau)
            ->where('statut', Reservation::EN_ATTENTE)
            ->where(function ($q) use ($reservation) {
                $q->where('date_heure_demande', '<', $reservation->date_heure_demande)
                    ->orWhere(function ($q2) use ($reservation) {
                        $q2->where('date_heure_demande', $reservation->date_heure_demande)
                            ->where('num_reservation', '<', $reservation->num_reservation);
                    });
            })
            ->count();

        return $avant + 1;
    }

    /** Un des jurys est-il déjà dans une réservation confirmée dont le créneau chevauche celui-ci ? */
    public function juryOccupe(Creneau $creneau, array $jurys): bool
    {
        return Reservation::where('statut', Reservation::CONFIRMEE)
            ->whereHas('jurys', fn ($q) => $q->whereIn('jurys.num_jury', $jurys))
            ->whereHas('creneau', function ($q) use ($creneau) {
                $q->where('date_creneau', $creneau->date_creneau->format('Y-m-d'))
                    ->where('heure_debut', '<', $creneau->heure_fin)
                    ->where('heure_fin', '>', $creneau->heure_debut);
            })
            ->exists();
    }

    private function debut(Creneau $creneau): Carbon
    {
        return Carbon::parse($creneau->date_creneau->format('Y-m-d') . ' ' . $creneau->heure_debut);
    }

    private function refuser(string $champ, string $message): never
    {
        throw ValidationException::withMessages([$champ => $message]);
    }
}
