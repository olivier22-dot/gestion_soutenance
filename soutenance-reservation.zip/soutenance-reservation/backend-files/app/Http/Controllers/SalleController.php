<?php

namespace App\Http\Controllers;

use App\Models\Salle;
use Illuminate\Database\Eloquent\Model;

class SalleController extends CrudController
{
    protected function modele(): string
    {
        return Salle::class;
    }

    protected function relations(): array
    {
        return ['emplacement'];
    }

    protected function regles(?Model $existant = null): array
    {
        $regles = [
            'capacite' => ['required', 'integer', 'min:1', 'max:5000'],
            'code_emplacement' => ['required', 'string', 'exists:emplacements,code_emplacement'],
        ];
        if (!$existant) {
            $regles['num_salle'] = ['required', 'string', 'max:20', 'unique:salles,num_salle'];
        }
        return $regles;
    }
}
