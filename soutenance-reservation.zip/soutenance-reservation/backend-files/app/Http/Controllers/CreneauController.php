<?php

namespace App\Http\Controllers;

use App\Models\Creneau;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\ValidationException;

class CreneauController extends CrudController
{
    protected function modele(): string
    {
        return Creneau::class;
    }

    protected function relations(): array
    {
        return ['salle'];
    }

    protected function ordre(): array
    {
        return ['date_creneau', 'heure_debut'];
    }

    protected function regles(?Model $existant = null): array
    {
        return [
            'date_creneau' => ['required', 'date_format:Y-m-d'],
            'heure_debut' => ['required', 'date_format:H:i'],
            'heure_fin' => ['required', 'date_format:H:i', 'after:heure_debut'],
            'num_salle' => ['required', 'string', 'exists:salles,num_salle'],
        ];
    }

    /** Deux créneaux ne peuvent pas se chevaucher dans la même salle. */
    protected function verifier(array $data, ?Model $existant = null): void
    {
        $chevauche = Creneau::where('num_salle', $data['num_salle'])
            ->where('date_creneau', $data['date_creneau'])
            ->where('heure_debut', '<', $data['heure_fin'])
            ->where('heure_fin', '>', $data['heure_debut'])
            ->when($existant, fn ($q) => $q->where('num_creneau', '!=', $existant->num_creneau))
            ->exists();

        if ($chevauche) {
            throw ValidationException::withMessages([
                'heure_debut' => 'Ce créneau chevauche un autre créneau de la même salle.',
            ]);
        }
    }
}
