<?php

namespace App\Http\Controllers;

use App\Models\Emplacement;
use Illuminate\Database\Eloquent\Model;

class EmplacementController extends CrudController
{
    protected function modele(): string
    {
        return Emplacement::class;
    }

    protected function regles(?Model $existant = null): array
    {
        $regles = ['adresse' => ['required', 'string', 'max:255']];
        if (!$existant) {
            $regles['code_emplacement'] = ['required', 'string', 'max:20', 'unique:emplacements,code_emplacement'];
        }
        return $regles;
    }
}
