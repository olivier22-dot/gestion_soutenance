<?php

namespace App\Http\Controllers;

use App\Models\Etudiant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class EtudiantController extends CrudController
{
    protected function modele(): string
    {
        return Etudiant::class;
    }

    protected function relations(): array
    {
        return ['encadreurs'];
    }

    protected function ordre(): array
    {
        return ['nom', 'prenoms'];
    }

    protected function regles(?Model $existant = null): array
    {
        $regles = [
            'nom' => ['required', 'string', 'max:100'],
            'prenoms' => ['required', 'string', 'max:150'],
            'niveau' => ['required', 'string', 'max:20'],
            'parcours' => ['required', 'string', 'max:100'],
            'telephone' => ['nullable', 'string', 'max:30'],
            'email' => [
                'required', 'email', 'max:150',
                Rule::unique('etudiants', 'email')->ignore($existant?->num_matricule, 'num_matricule'),
            ],
            'visa_soutenance' => ['boolean'],
            'rapport_lecture' => ['boolean'],
            'memoire' => ['nullable', 'string', 'max:255'],
        ];
        if (!$existant) {
            $regles['num_matricule'] = ['required', 'string', 'max:20', 'unique:etudiants,num_matricule'];
        }
        return $regles;
    }

    /** Association ENCADREUR : définit les encadreurs (jurys) d'un étudiant. */
    public function encadreurs(Request $request, string $id)
    {
        $etudiant = Etudiant::findOrFail($id);
        $data = $request->validate([
            'jurys' => ['present', 'array'],
            'jurys.*' => ['integer', 'distinct', 'exists:jurys,num_jury'],
        ]);
        $etudiant->encadreurs()->sync($data['jurys']);

        return $etudiant->load('encadreurs');
    }
}
