<?php

namespace App\Http\Controllers;

use App\Models\Reservation;
use App\Services\ReservationService;
use Illuminate\Http\Request;

class ReservationController extends Controller
{
    private const RELATIONS = ['etudiant', 'creneau.salle.emplacement', 'jurys'];

    public function __construct(private ReservationService $service)
    {
    }

    public function index(Request $request)
    {
        $reservations = Reservation::with(self::RELATIONS)
            ->when($request->query('matricule'), fn ($q, $m) => $q->where('num_matricule', $m))
            ->orderByDesc('date_heure_demande')
            ->orderByDesc('num_reservation')
            ->get();

        return $reservations->map(fn ($r) => $this->formater($r));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'num_matricule' => ['required', 'string', 'exists:etudiants,num_matricule'],
            'num_creneau' => ['required', 'integer', 'exists:creneaux,num_creneau'],
            'jurys' => ['required', 'array', 'size:3'],
            'jurys.*' => ['integer', 'distinct', 'exists:jurys,num_jury'],
        ]);

        $reservation = $this->service->demander($data['num_matricule'], $data['num_creneau'], $data['jurys']);

        return response()->json($this->formater($reservation->load(self::RELATIONS)), 201);
    }

    public function annuler(string $id)
    {
        [$annulee, $promue] = $this->service->annuler((int) $id);

        return [
            'reservation' => $this->formater($annulee->load(self::RELATIONS)),
            'promue' => $promue ? $this->formater($promue->load(self::RELATIONS)) : null,
        ];
    }

    private function formater(Reservation $reservation): Reservation
    {
        $reservation->setAttribute('position', $this->service->position($reservation));
        return $reservation;
    }
}
