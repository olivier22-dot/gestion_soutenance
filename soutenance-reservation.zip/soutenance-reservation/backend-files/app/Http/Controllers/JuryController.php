<?php

namespace App\Http\Controllers;

use App\Models\Jury;
use Illuminate\Database\Eloquent\Model;

class JuryController extends CrudController
{
    protected function modele(): string
    {
        return Jury::class;
    }

    protected function ordre(): array
    {
        return ['nom', 'prenoms'];
    }

    protected function regles(?Model $existant = null): array
    {
        return [
            'nom' => ['required', 'string', 'max:100'],
            'prenoms' => ['required', 'string', 'max:150'],
            'grade' => ['required', 'string', 'max:100'],
            'role' => ['required', 'string', 'max:100'],
        ];
    }
}
